package com.ejemplo.consumirrest;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConsumirRestApplicationTests {

	@Test
	void contextLoads() {
	}

}
